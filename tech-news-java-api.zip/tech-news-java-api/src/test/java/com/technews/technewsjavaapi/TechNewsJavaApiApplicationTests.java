package com.technews.technewsjavaapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechNewsJavaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
